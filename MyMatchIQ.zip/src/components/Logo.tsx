import logo from 'figma:asset/901f9adb7b43e5a118d5aa4f00060973c682c6f3.png';

interface LogoProps {
  className?: string;
  size?: number;
}

export function Logo({ className = "", size = 48 }: LogoProps) {
  return (
    <img 
      src={logo} 
      alt="MyMatchIQ Logo" 
      className={className}
      style={{ 
        width: size, 
        height: size, 
        objectFit: 'contain'
      }} 
    />
  );
}